**To delete a stack**

The following ``delete-stack`` example deletes the specified stack. ::

    aws cloudformation delete-stack \
        --stack-name my-stack

This command produces no output.